# Aula de Gerenciamento de Configuração de Software

Este repositório é usado para praticar versionamento com Git e GitHub.